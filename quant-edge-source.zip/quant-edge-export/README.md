# QUANT-EDGE Institutional Investment Terminal

Piattaforma di valutazione azionaria istituzionale full-stack con estetica Bloomberg Terminal.

## Stack
- **Backend**: FastAPI + Python (yfinance, numpy, pandas)
- **Frontend**: React 19 + Recharts + Tailwind CSS
- **Database**: MongoDB (opzionale)
- **AI**: Emergent Universal LLM Key (Claude Sonnet 4.6) — gratuita

## Features
- DCF 3-stage (Gordon + Exit Multiple)
- WACC dinamico, Reverse DCF, DDM, Multipli comparabili
- Composite Fair Value ponderato
- Monte Carlo 2.500 simulazioni + VaR/CVaR 95%
- Peer benchmarking automatico
- Report AI streaming in italiano (Claude Sonnet)
- Live macro ticker (10Y, VIX, DXY, Gold, WTI, S&P, BTC)
- News feed via Google News RSS

## Setup locale

### Backend
```bash
cd backend
python3 -m venv venv
source venv/bin/activate   # su Windows: venv\Scripts\activate
pip install -r requirements.txt

# crea backend/.env con:
# MONGO_URL="mongodb://localhost:27017"
# DB_NAME="quantedge"
# CORS_ORIGINS="*"
# EMERGENT_LLM_KEY=sk-emergent-XXXXX   # richiedila su emergent.sh

uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend
```bash
cd frontend
yarn install   # oppure: npm install

# crea frontend/.env con:
# REACT_APP_BACKEND_URL=http://localhost:8001

yarn start     # oppure: npm start
```

Apri http://localhost:3000

## Deploy gratuito

- **Backend**: [Render](https://render.com) o [Railway](https://railway.app) → free tier per FastAPI
- **Frontend**: [Vercel](https://vercel.com) o [Netlify](https://netlify.com) → free tier per React
- **MongoDB**: [MongoDB Atlas Free Tier](https://www.mongodb.com/atlas) (opzionale, l'app funziona anche senza)

## API Endpoints
| Endpoint | Descrizione |
|---|---|
| `GET  /api/asset/{ticker}` | Dati bilancio + prezzo + storico |
| `POST /api/valuation` | Composite fair value (DCF + DDM + Multipli) |
| `POST /api/montecarlo` | 2.500 simulazioni + VaR/CVaR |
| `POST /api/sensitivity` | Heatmap WACC × Growth |
| `GET  /api/peers/{ticker}` | Peer benchmarking |
| `GET  /api/news/{ticker}` | Google News RSS |
| `GET  /api/macro` | Macro ticker live |
| `POST /api/ai/research` | Report AI streaming (SSE) |

## Licenza
MIT — libero di usare, modificare, distribuire.

---
Built with ❤️ on Emergent Platform.
